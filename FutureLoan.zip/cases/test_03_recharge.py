# Author: Cup
# Time: 2019/11/23 22:59

import unittest
import json
from datetime import datetime
from scripts.handle_requests import FutureLoan
from scripts.operate_excel import OperateExcel
from libs.ddt import ddt,data
from scripts.log_info import log
from scripts.my_config import YmlConfig
from scripts.handle_re import HandleRe
from scripts.handle_mysql import HandleSql

@ddt
class TestCaseRecharge(unittest.TestCase):
    config = YmlConfig()
    excel = OperateExcel('recharge')
    cases = excel.read_excel_obj()

    @classmethod
    def setUpClass(cls):
        '''
        添加公共请求头，请求头写在配置文件中
        :return:
        '''
        cls.reqst_2 = FutureLoan()
        cls.reqst_2.add_headers()
        cls.execute_sql = HandleSql()

    # 充值接口测试
    @data(*cases)
    def test_recharge(self,case):
        row = case.case_id + 1
        data = case.datas
        new_data = HandleRe().sub_strings(data)

        # 判断check_sql列是否为空，若不为空，还需进行后台数据校验
        check_sql = case.check_sql
        if case.check_sql:
            sql = HandleRe().sub_strings(check_sql)
            amount_before = self.execute_sql.get_value(sql,is_more=False)['leave_amount']
            amount_before = round(float(amount_before),2)
        # 发起请求，获取实际结果的返回code
        actua_res = self.reqst_2.deal_request(url=case.url,method=case.method,param=new_data)
        actual_code = actua_res.json()['code']
        # 预期结果，获取预期结果的code
        expect_code = int(case.expected)
        # 读取配置文档中的具体列数
        actual_col = self.config.read_yml_config('excel','actual_col')
        res_col = self.config.read_yml_config('excel','res_col')
        created_date_col = self.config.read_yml_config('excel','created_date_col')

        try:
            self.assertEqual(actual_code, expect_code,msg=case.title)
            if check_sql:
                # 获取充值后数据库中的金额
                sql = HandleRe().sub_strings(check_sql)

                amount_after = self.execute_sql.get_value(sql,is_more=False)
                amount_after = round(float(amount_after['leave_amount']), 2)
                # 查看后台数据库中的实际变动金额数值
                amount_actual = round((amount_after - amount_before),2)
                # 获取测试用例中的充值金额
                amount_case = json.loads(new_data, encoding='utf-8')['amount']
                self.assertEqual(amount_actual,amount_case,msg='后台充值金额有误！')
        except AssertionError as e:
            self.excel.write_excel(row=row, column=res_col, value='不通过')
            log.info(F'用例 {case.title} 执行未通过')
            log.error(e)
            raise e
        else:
            # 判断结果中是否存在token
            if 'token_info' in actua_res.text:
                token = actua_res.json()['data']['token_info']['token']
                headers = {"Authorization": "Bearer " + token}
                self.reqst_2.add_headers(headers)
            self.excel.write_excel(row=row, column=res_col, value='通过')
            log.info(F'用例 {case.title} 执行通过')
        finally:
            self.excel.write_excel(row=row, column=actual_col, value=actua_res.text)
            self.excel.write_excel(row=row, column=created_date_col,value=datetime.strftime(datetime.now(), '%Y-%m-%d %H:%M:%S'))

    @classmethod
    def tearDownClass(cls):
        cls.reqst_2.close()
        cls.execute_sql.close()
