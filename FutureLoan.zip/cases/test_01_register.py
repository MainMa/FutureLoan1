# Author: Cup
# Time: 2019/10/23 23:27
import unittest
import json
from datetime import datetime
from scripts.handle_requests import FutureLoan
from scripts.operate_excel import OperateExcel
from libs.ddt import ddt,data
from scripts.log_info import log
from scripts.my_config import YmlConfig
from scripts.handle_re import HandleRe


@ddt
class RegisterTestCase(unittest.TestCase):
    config = YmlConfig()
    excel = OperateExcel('register')
    cases = excel.read_excel_obj()

    @classmethod
    def setUpClass(cls):
        '''
        添加公共请求头，请求头写在配置文件中
        :return:
        '''
        cls.reqst_1 = FutureLoan()
        cls.reqst_1.add_headers()

    # 注册接口测试
    @data(*cases)
    def test_register(self,case):
        row = case.case_id + 1
        data = str(json.loads(case.datas))
        new_data = HandleRe().sub_strings(data)
        # 实际结果

        actua_res = self.reqst_1.deal_request(url=case.url,method=case.method,param=new_data)
        actual_code = actua_res.json()['code']
        # 预期结果
        expect_code = int(case.expected)
        actual_col = self.config.read_yml_config('excel','actual_col')
        res_col = self.config.read_yml_config('excel','res_col')
        created_date_col = self.config.read_yml_config('excel','created_date_col')
        try:
            self.assertEqual(actual_code, expect_code)
        except AssertionError as e:
            self.excel.write_excel(row=row, column=res_col, value='不通过')
            log.info(F'用例 {case.title} 执行未通过')
            log.error(e)
            raise e
        else:
            self.excel.write_excel(row=row, column=res_col, value='通过')
            log.info(F'用例 {case.title} 执行通过')
        finally:
            self.excel.write_excel(row=row, column=actual_col, value=actua_res.text)
            self.excel.write_excel(row=row, column=created_date_col,value=datetime.strftime(datetime.now(), '%Y-%m-%d %H:%M:%S'))


    @classmethod
    def tearDownClass(cls):
        cls.reqst_1.close()