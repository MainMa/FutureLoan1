# Author: Cup
# Time: 2019/11/24 22:40

import unittest
from datetime import datetime
from scripts.handle_requests import FutureLoan
from scripts.operate_excel import OperateExcel
from libs.ddt import ddt,data
from scripts.log_info import log
from scripts.my_config import YmlConfig
from scripts.handle_re import HandleRe
from scripts.handle_mysql import HandleSql

@ddt
class TestCaseInvest(unittest.TestCase):
    config = YmlConfig()
    excel = OperateExcel('invest')
    cases = excel.read_excel_obj()

    @classmethod
    def setUpClass(cls):
        '''
        添加公共请求头，请求头写在配置文件中
        :return:
        '''
        cls.reqst_4 = FutureLoan()
        cls.reqst_4.add_headers()
        cls.execute_sql = HandleSql()

    # 投资接口测试
    @data(*cases)
    def test_invest(self,case):
        row = case.case_id + 1
        data = case.datas
        deal_re = HandleRe()
        new_data = deal_re.sub_strings(data)
        # 发起请求，获取实际结果的返回code
        actua_res = self.reqst_4.deal_request(url=case.url,method=case.method,param=new_data)
        actual_code = actua_res.json()['code']
        # 预期结果，获取预期结果的code
        expect_code = int(case.expected)
        # 读取配置文档中的具体列数
        actual_col = self.config.read_yml_config('excel','actual_col')
        res_col = self.config.read_yml_config('excel','res_col')
        created_date_col = self.config.read_yml_config('excel','created_date_col')

        try:
            self.assertEqual(actual_code, expect_code,msg=case.title)
        except AssertionError as e:
            self.excel.write_excel(row=row, column=res_col, value='不通过')
            log.info(F'用例 {case.title} 执行未通过')
            log.error(e)
            raise e
        else:
            # 判断结果中是否存在token
            if 'token_info' in actua_res.text:
                token = actua_res.json()['data']['token_info']['token']
                headers = {"Authorization": "Bearer " + token}
                self.reqst_4.add_headers(headers)
            self.excel.write_excel(row=row, column=res_col, value='通过')
            log.info(F'用例 {case.title} 执行通过')
            if case.case_id == 2:
                loan_id = actua_res.json().get('data').get('id')
                setattr(HandleRe,'loan_id',loan_id)
        finally:
            self.excel.write_excel(row=row, column=actual_col, value=actua_res.text)
            self.excel.write_excel(row=row, column=created_date_col,value=datetime.strftime(datetime.now(), '%Y-%m-%d %H:%M:%S'))

    @classmethod
    def tearDownClass(cls):
        cls.reqst_4.close()
        cls.execute_sql.close()
