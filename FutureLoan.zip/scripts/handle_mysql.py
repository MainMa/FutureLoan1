# Author: Cup
# Time: 2019/11/16 17:50

import pymysql
import pprint
import random
from scripts.my_config import YmlConfig

class HandleSql:
    '''
    用来处理数据库的相关操作
    '''
    def __init__(self):
        '''
        连接数据库
        '''
        try:
            self.knet = pymysql.connect(host=YmlConfig().read_yml_config('mysql','host'),
                                   user=YmlConfig().read_yml_config('mysql','user'),
                                   password=YmlConfig().read_yml_config('mysql','password'),
                                   db=YmlConfig().read_yml_config('mysql','db'),
                                   port=YmlConfig().read_yml_config('mysql','port'),
                                   charset='utf8',
                                   cursorclass=pymysql.cursors.DictCursor
                                   )
            self.ksor = self.knet.cursor()
        except Exception as e:
            print(e)

    def get_value(self,sql,args=None,is_more=True):
        '''
        返回sql的搜索结果
        参数sql(必传)：需要查询的内容
        参数args（选填）：sql中的变量，如手机号、用户名
        参数is_more（选填）：是否需要返回多条结果
        '''
        self.ksor.execute(sql, args)
        self.knet.commit()
        if is_more:
            # 返回列表嵌套字典/元组的数据
            return self.ksor.fetchall()
        else:
            # 返回字典或元组类型
            return self.ksor.fetchone()

    @staticmethod
    def create_mobile():
        '''
        随机生成130开头的手机号
        :return:
        '''
        lst8 =random.sample('0123456789',8)
        mobile = '130'+''.join(lst8)
        return mobile

    def if_exist_mobile(self,mobile):
        '''
        判断数据库中是否存在该手机号，若已存在返回true，不存在返回false
        :param mobile:
        :return:
        '''
        sql_3 = YmlConfig().read_yml_config('mysql','select_user_sql')
        if self.get_value(sql_3,args=[mobile]):
            return True
        else:
            return False

    def create_not_existed_mobile(self):
        '''
        创建一个在数据库中不存在的手机号
        :return:
        '''
        while True:
            mobile_phone = self.create_mobile()
            if not self.if_exist_mobile(mobile_phone):
                break
        # 此时这个手机号是未注册的号码
        return mobile_phone

    def close(self):
        self.ksor.close()
        self.knet.close()

if __name__ == '__main__':
    handle_sql = HandleSql()
    # sql_1 = "select * from member where mobile_phone = '15195818365';"
    # sql_2 = "select * from member where type = %s limit 5;"
    # type = 1
    # print(handle_sql.get_value(sql_1))
    # pprint.pprint(handle_sql.get_value(sql_2,args=[type]))
    # mobile_phone = handle_sql.create_not_existed_mobile()
    sql = 'SELECT ID FROM LOAN WHERE STATUS<>2;'
    data = handle_sql.get_value(sql,is_more=False)
    # print(mobile_phone)
    print(data)