# Author: Cup
# Time: 2019/11/17 1:55
import re
import pprint
from scripts.handle_mysql import HandleSql
from scripts.my_config import YmlConfig
from scripts.handle_path import USER_INFO_CONF_FILE

class HandleRe:
    NOT_EXIST_MOBILE = r'{not_exist_mobile}'
    NOT_EXIST_ID = r'{not_existed_id}'
    INVESTED_MOBILE = r'{invested_mobile}'
    INVESTED_PWD = r'{invested_pwd}'
    INVESTED_ID = r'{invested_id}'
    LOANER_ID = r'{loaner_id}'
    LOANER_MOBILE = r'{loaner_mobile}'
    LOANER_PWD = r'{loaner_pwd}'
    ADMIN_MOBILE = r'{admin_mobile}'
    ADMIN_PWD = r'{admin_pwd}'
    NOT_BIDDING_LOAN_ID = r'{not_bidding_loan_id}'
    LOAN_ID = r'{loan_id}'

    @classmethod
    def sub_strings(cls, data):
        '''
        将测试用例中的${}包裹起来的参数替换为未注册的手机号码
        :param sub_str: 要替换的字符串
        :param data: 原始字符串
        :return:
        '''
        exe_sql = HandleSql()
        if re.search(cls.NOT_EXIST_MOBILE,data):
            # 创建未注册的手机号
            mobile = exe_sql.create_not_existed_mobile()
            data = re.sub(cls.NOT_EXIST_MOBILE,mobile,data)
            exe_sql.close()

        if re.search(cls.INVESTED_MOBILE,data):
            # 从配置文档中读取投资人手机号
            mobile_phone = YmlConfig(USER_INFO_CONF_FILE).read_yml_config('invester','mobile_phone')
            data = re.sub(cls.INVESTED_MOBILE, mobile_phone, data)

        if re.search(cls.INVESTED_PWD,data):
            # 从配置文档中读取投资人密码
            pwd = YmlConfig(USER_INFO_CONF_FILE).read_yml_config('invester','pwd')
            data = re.sub(cls.INVESTED_PWD, pwd, data)

        if re.search(cls.INVESTED_ID,data):
            id = str(YmlConfig(USER_INFO_CONF_FILE).read_yml_config('invester','id'))
            data = re.sub(cls.INVESTED_ID,id,data)

        if re.search(cls.NOT_EXIST_ID,data):
            select_max_userid = YmlConfig().read_yml_config('mysql','select_max_userid')
            id = str(exe_sql.get_value(select_max_userid,is_more=False)['MAX(ID)']+1)
            data = re.sub(cls.NOT_EXIST_ID,id,data)
            exe_sql.close()

        if re.search(cls.LOANER_ID,data):
            id = str(YmlConfig(USER_INFO_CONF_FILE).read_yml_config('loaner','id'))
            data = re.sub(cls.LOANER_ID,id,data)
            return data

        if re.search(cls.LOANER_MOBILE,data):
            mobile = YmlConfig(USER_INFO_CONF_FILE).read_yml_config('loaner','mobile_phone')
            data = re.sub(cls.LOANER_MOBILE,mobile,data)

        if re.search(cls.LOANER_PWD,data):
            pwd = YmlConfig(USER_INFO_CONF_FILE).read_yml_config('loaner','pwd')
            data = re.sub(cls.LOANER_PWD,pwd,data)

        if re.search(cls.ADMIN_MOBILE,data):
            mobile = YmlConfig(USER_INFO_CONF_FILE).read_yml_config('admin','mobile_phone')
            data = re.sub(cls.ADMIN_MOBILE,mobile,data)

        if re.search(cls.ADMIN_PWD,data):
            pwd = YmlConfig(USER_INFO_CONF_FILE).read_yml_config('admin','pwd')
            data = re.sub(cls.ADMIN_PWD,pwd,data)

        if re.search(cls.LOAN_ID,data):
            id = getattr(cls, 'loan_id')
            data = re.sub(cls.LOAN_ID,str(id),data)

        if re.search(cls.NOT_BIDDING_LOAN_ID,data):
            sql = YmlConfig().read_yml_config('mysql','select_not_bidding_loan_id')
            id = str(exe_sql.get_value(sql,is_more=False).get('ID'))
            data = re.sub(cls.NOT_BIDDING_LOAN_ID,id,data)

        return data




if __name__ == '__main__':
    data = '{"mobile_phone": "{not_exist_mobile}","pwd": "12345678"}'
    data_2 = '{"mobile_phone": "{invested_mobile}", "pwd": "{invested_pwd}"}'
    mobile_phone = YmlConfig(USER_INFO_CONF_FILE).read_yml_config('invester', 'mobile_phone')
    new_data = HandleRe().sub_strings(data_2)
    print(mobile_phone)
    print(new_data)