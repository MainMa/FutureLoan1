# Author: Cup
# Time: 2019/11/16 23:48

import os

# 获取当前路径的上层路径
SCRIPTS_DIR = os.path.dirname(__file__)

# 通过刚刚获取的scripts的路径来获取根目录路径
ROOT_DIR = os.path.dirname(SCRIPTS_DIR)

# 配置文件的文件夹路径, 与配置文件的位置
CONFIGS_DIR = os.path.join(ROOT_DIR,'configs')
CONFIGS_FILE = os.path.join(CONFIGS_DIR,'my_config_2.yml')

# 日志文件的文件夹路径，与日志文件的位置
LOGS_DIR = os.path.join(ROOT_DIR,'logs')
LOGS_FILE = os.path.join(LOGS_DIR,'log_info.log')

# 报告文件的文件夹路径
REPORTS_DIR = os.path.join(ROOT_DIR,'reports')

# 测试数据文件的文件夹路径，与测试数据文件的位置
DATAS_DIR = os.path.join(ROOT_DIR,'datas')

# 项目相关管理员、投资人、借款人信息配置文档
USER_INFO_CONF_FILE = os.path.join(CONFIGS_DIR,'user_info_conf.yml')

# 获取用例执行类的文件夹路径
CASES_DIR = os.path.join(ROOT_DIR,'cases')