# Author: Cup
# Time: 2019/11/9 23:40
import requests
import json
from scripts.my_config import YmlConfig
from scripts.handle_path import CONFIGS_FILE

class FutureLoan:
    '''前程贷项目的注册、登录、充值接口'''
    config = YmlConfig(CONFIGS_FILE)
    ip = config.read_yml_config('future_loan', 'ip')
    headers = config.read_yml_config('future_loan','default_headers')

    def __init__(self):
        self.one_session = requests.Session()

    def add_headers(self,headers=headers):
        self.one_session.headers.update(headers)

    def deal_request(self,url,method='post',param=None,is_json=True,**kwargs):
        '''参数：
        url：请求的地址
        method：请求的方法
        param：请求的参数（支持字典类型、字典类型的字符串、json字符串三种形式）
        is_json： 是否是json格式的数据
        返回响应结果，具体信息可通过属性名获取'''
        url = self.ip + url
        if isinstance(param, str):
            try:
                param = json.loads(param)
            except Exception as e:
                param = eval(param)
        method = method.lower()
        if method == "get":
            res = self.one_session.request(method, url, params=param, **kwargs)
        elif method in ("post", "put", "delete", "patch"):
            if is_json:
                res = self.one_session.request(method, url, json=param, **kwargs)
            else:
                res = self.one_session.request(method, url, data=param, **kwargs)
        else:
            res = None
            print(F'无法使用 {method} 方法进行请求')
        return res

    def close(self):
        '''
        关闭session对象
        '''
        self.one_session.close()

if __name__ == '__main__':
    # 1.1 字典类型的参数
    param_1 = {"mobile_phone": "13315156001", "pwd": "12345678", "reg_name": None}
    # 1.2 字典类型的字符串参数
    param_2 = '{"mobile_phone": "13315156002", "pwd": "12345678","reg_name": None}'
    # 1.3 json字符串
    param_3 = '{"mobile_phone": "13315156003", "pwd": "12345678","reg_name": null}'
    # 2.1 字典类型的参数
    param_login1 = {"mobile_phone": "13315156001", "pwd": "12345678"}
    # 2.2 字典类型的字符串参数
    param_login2 = '{"mobile_phone": "13315156002", "pwd": "12345678"}'
    # 2.3 json字符串
    param_login3 = '{"mobile_phone": "13315156003", "pwd": "12345678"}'
    # res_register = FutureLoan().register('/member/register','post',param=param_3)
    res_1 = FutureLoan()
    res_1.add_headers()
    res_login = res_1.deal_request(url='/member/login',param=param_login3)
    # res_recharge = FutureLoan().charge('/member/recharge','post',param_login=param_login1,recharge_amount=100.38)
    print(res_login.text)

