# Author: Cup
# Time: 2019/10/26 15:29
import os
import pprint
from openpyxl import load_workbook
from scripts.handle_path import DATAS_DIR
from scripts.my_config import YmlConfig


class cases_obj:
    pass

class OperateExcel:
    def __init__(self,sheet_name,file_name=None):
        if file_name is None:
            self.file_name = os.path.join(DATAS_DIR,YmlConfig().read_yml_config('excel','excel_name'))
        else:
            self.file_name = file_name
        super().__init__()
        self.sheet_name = sheet_name

    def open_excel(self):
        self.wb = load_workbook(self.file_name)
        self.ws = self.wb[self.sheet_name]

    def read_excel(self):
        '''返回一个由多个字典组合成的列表'''
        self.open_excel()
        row = list(self.ws.rows)
        cases = []
        case_title = [i.value for i in row[0]]
        for row_info in row[1:]:
            case_info = [j.value for j in row_info]
            cases.append(dict(zip(case_title,case_info)))
        self.wb.close()
        return cases

    def read_excel_obj(self):
        '''返回一个由多个对象组合成的列表'''
        self.open_excel()
        row = list(self.ws.rows)
        case_obj = []
        case_title = [i.value for i in row[0]]
        for row_info in row[1:]:
            new_case_obj = cases_obj()
            case_info = [j.value for j in row_info]
            data = dict(zip(case_title, case_info))
            # print(data)
            for k,v in data.items():
                setattr(new_case_obj,k,v)
            case_obj.append(new_case_obj)
        self.wb.close()
        return case_obj

    def write_excel(self,row,column,value):
        self.open_excel()
        self.ws.cell(row=row,column=column,value=value)
        self.wb.save(self.file_name)
        self.wb.close()
        pass

if __name__ == '__main__':
    api_path = r'G:\FutureLoan\datas\APIcases.xlsx'
    read = OperateExcel('register',file_name=api_path)
    res = read.read_excel()
    pprint.pprint(res)