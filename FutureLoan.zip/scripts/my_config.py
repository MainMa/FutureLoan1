# Author: Cup
# Time: 2019/11/2 10:12

from configparser import ConfigParser
import yaml
import pprint
from scripts.handle_path import CONFIGS_FILE


class ConfConfig(ConfigParser):
    def __init__(self,file_name):
        super().__init__(self)
        self.file_name = file_name
        self.config = ConfigParser()

    def read_conf_config(self,section_name,key):
        '''获取配置文件中的配置信息'''
        # 获取配置文件内容
        self.config.read(self.file_name,encoding='utf-8')
        # 读取具体内容，传两个参数，一个区域名，第二个选项名
        # 方法一
        res_1 = eval(self.config[section_name][key])
        # 方法二
        # res_2 = config.getint('excel','actual_col')
        return res_1

    def write_conf_config(self,datas):
        '''将配置信息写入配置文件中，目前只能在文件末尾处新增内容
        无法在指定区域下新增配置信息'''
        config = ConfigParser()
        for key in datas:
            config[key] = datas[key]
        with open(self.file_name,'a',encoding='utf-8') as f:
            config.write(f)

class YmlConfig:
    '''操作yml文件'''
    def __init__(self,file_name=CONFIGS_FILE):
        self.file_name = file_name
        with open(self.file_name,encoding="utf-8") as f:
            self.data = yaml.full_load(f)

    def read_yml_config(self,section_name,key):
        '''
        读取配置信息,传入两个参数
        :param section_name: 分区名
        :param key: 分区下配置的键名
        :return: 配置的结果
        '''
        value = self.data[section_name][key]
        return value

    @staticmethod
    def write_yml_config(file_name,data):
        # 写入配置信息
        with open(file=file_name,mode='w',encoding='utf8') as f:
            yaml.dump(data,f,allow_unicode=True)


if __name__ == '__main__':
    # config = ConfConfig(file_name='my_config_1.conf')
    # value = config.read_conf_config('excel','res_col')
    # print(type(value),value)
    data = {'host':{'name':'cup','pwd':123456,'port':8080},'table':{'name':'user_info','descripition':'存储用户信息'}}
    # config.write_conf_config(data)
    yml_config = YmlConfig()
    print(yml_config.read_yml_config('mysql','select_user_sql'))
    # yml_config.write_yml_config(data)
