# Author: Cup
# Time: 2019/10/30 21:21
import logging
from scripts.my_config import YmlConfig
from scripts.handle_path import LOGS_FILE

class LogInfo:
    @classmethod
    def create_logger(cls):
        config = YmlConfig()
        logger_name = config.read_yml_config('log','logger_name')
        '''创建自己的日志收集器'''
        # 设置日志收集器
        cup_log = logging.getLogger(logger_name)
        # 设置日志收集等级
        log_level = config.read_yml_config('log', 'log_level')
        cup_log.setLevel(log_level)
        # 把日志输出到控制台
        run_log = logging.StreamHandler()
        # 把日志输出到文件
        file_log = logging.FileHandler(filename=LOGS_FILE, encoding='utf8')
        # 设置输出等级
        stream_level = config.read_yml_config('log', 'stream_level')
        log_file_level = config.read_yml_config('log', 'log_file_level')
        run_log.setLevel(stream_level)
        file_log.setLevel(log_file_level)
        # 把输出渠道（run_log）添加到日志收集器(cup_log)里
        cup_log.addHandler(run_log)
        # 把输出渠道（filelog）添加到日志收集器(cup_log)里
        cup_log.addHandler(file_log)
        # 设置输出格式
        formatter = config.read_yml_config('log', 'formatter')
        formater_1 = logging.Formatter(formatter)
        # 绑定格式到输出渠道(控制台、文件)
        run_log.setFormatter(formater_1)
        file_log.setFormatter(formater_1)
        # 打印日志
        # cup_log.debug('debug')
        # cup_log.info('info')
        # cup_log.warning('warning')
        # cup_log.error('error')
        return cup_log

log = LogInfo.create_logger()

if __name__ == '__main__':
    test_1 = LogInfo.create_logger()
    test_1.info('info新嘻嘻嘻嘻嘻嘻')