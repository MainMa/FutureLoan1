# Author: Cup
# Time: 2019/11/22 22:20
from scripts.handle_requests import FutureLoan
from scripts.handle_mysql import HandleSql
from scripts.my_config import YmlConfig
from scripts.handle_path import CONFIGS_FILE
from scripts.handle_path import USER_INFO_CONF_FILE

class HandleUser:
    @staticmethod
    def create_user(reg_name=None,pwd="12345678",type=1):
        '''
        注册用户
        :param reg_name:用户名，可不填，默认为孔
        :param pwd: 密码，可不填，默认为12345678
        :param type: 用户类型，可不填，默认为普通用户，0管理员，1普通用户
        :return: 用户ID，用户名，密码，类型
        '''
        requests_1 = FutureLoan()
        sql_1 = HandleSql()
        select_userid_sql = YmlConfig().read_yml_config('mysql', 'select_userid_sql')
        # 添加公共请求头
        requests_1.add_headers()
        while True:
            # 准备参数
            mobile_phone = sql_1.create_not_existed_mobile()
            data = {"mobile_phone": mobile_phone,
                    "pwd": pwd,
                    "type": type,
                    "reg_name": reg_name}
            # 注册并获取响应结果
            response = requests_1.deal_request('/member/register',param=data)
            # 判断是否注册成功,若注册成功，获取用户id
            result = sql_1.get_value(select_userid_sql,args=[mobile_phone],is_more=False)
            if result:
                user_id = result['id']
                break
        # 将参数写入配置文件
        user_data = {"id": user_id,
                    "mobile_phone": mobile_phone,
                    "pwd": pwd,
                    "type": type,
                    "reg_name": reg_name}
        user_dict = {
            reg_name: user_data
        }
        # 关闭连接
        requests_1.close()
        sql_1.close()
        return user_dict

    def create_user_conf(self):
        user_conf_dict = {}
        admin = self.create_user(reg_name='admin',type=0)
        invester = self.create_user(reg_name='invester')
        loaner = self.create_user(reg_name='loaner')
        user_conf_dict.update(admin)
        user_conf_dict.update(invester)
        user_conf_dict.update(loaner)
        YmlConfig().write_yml_config(USER_INFO_CONF_FILE,user_conf_dict)

if __name__ == '__main__':
    HandleUser().create_user_conf()